package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class RunLogin extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setValues() {
	   fileName="Login";

	}
	
	
	@Test(dataProvider = "fetchData")
	public void runLogin() {
				
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.verifyHomePage()
		;
		
	}

}
