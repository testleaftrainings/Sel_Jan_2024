package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import config.Configuration;

public class MyLeadsPage extends ProjectSpecificMethods{
	
	public MyLeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public CreateLeadPage clickCreateLeadLink() {
		String createLeadLink = Configuration.configuration().getCreateLeadLink();
		driver.findElement(By.partialLinkText(createLeadLink)).click();
		return new CreateLeadPage(driver);

	}
	

}
