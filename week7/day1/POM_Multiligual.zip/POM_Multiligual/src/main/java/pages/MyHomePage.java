package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;
import config.Configuration;

public class MyHomePage extends ProjectSpecificMethods{
	
	public MyHomePage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public MyLeadsPage clickLeadsLink() {
		String leadsLink = Configuration.configuration().getLeadsLink();
		
		driver.findElement(By.linkText(leadsLink)).click();
		return new MyLeadsPage(driver);

	}

}
