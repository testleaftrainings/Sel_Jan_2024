package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{
	
	public ViewLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	
	public ViewLeadPage verifyLeads(String cName) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cName)) {
			System.out.println("Lead is created Successfully");
		}else {
			System.out.println("Lead is not created Successfully");
		}
		return this;

	}

}
