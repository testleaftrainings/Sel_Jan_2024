package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends ProjectSpecificMethods{
	
	@Then("HomePage should be displayed")
	public WelcomePage verifyHomePage() {
		String text = getDriver().findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("HomePage is displayed");
		}
		else {
			System.out.println("HomePage is not displayed");
		}
		return this;

	}

	@When("Click on crmsfa link")
	public MyHomePage clickCRMSFALink() {
		getDriver().findElement(By.partialLinkText("SFA")).click();
		return new MyHomePage();

	}
	
}
