package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethods extends AbstractTestNGCucumberTests{

	private static final ThreadLocal<ChromeDriver> chDriver = new ThreadLocal<ChromeDriver>();
	public String fileName,testName,testDescription,testAuthor,testCategory;
	public static ExtentReports extent;
	public static ExtentTest test ;

	public void setDriver() {
		chDriver.set(new ChromeDriver());
	}

	public ChromeDriver getDriver() {
		return chDriver.get();
	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void assignTestDetails() {
		test = extent.createTest(testName,testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
	
	public int takeSnap() throws IOException {
		int ranNum= (int) (Math.random() * 9999999 + 9999999);
		File src = getDriver().getScreenshotAs(OutputType.FILE);
		File dest = new File("./snaps/img"+ranNum+".png");// "++"
		FileUtils.copyFile(src, dest);
		return ranNum;
	}
	
	public void reportStep(String msg,String status) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			test.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
		}else if (status.equalsIgnoreCase("fail")) {
			test.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath(".././snaps/img"+takeSnap()+".png").build());
			throw new RuntimeException("View reports for details");
		}

	}
     
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}  


	@BeforeMethod
	public void preCondition() {
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

	}

	@AfterMethod
	public void postCondition() {
		getDriver().quit();		

	}


	@DataProvider(name="fetchData",parallel=true,indices=1)
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcel(fileName);

	}

}
