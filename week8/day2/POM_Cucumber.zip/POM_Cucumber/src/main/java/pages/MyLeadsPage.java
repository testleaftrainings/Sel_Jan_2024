package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;

public class MyLeadsPage extends ProjectSpecificMethods{
	
	
	@And("Click CreateLead Link")
	public CreateLeadPage clickCreateLeadLink() {
		driver.findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();

	}
	

}
