package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.Then;

public class ViewLeadPage extends ProjectSpecificMethods{
	
	
	@Then("ViewLeads page should be displayed as (.*)$")
	public ViewLeadPage verifyLeads(String cName) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cName)) {
			System.out.println("Lead is created Successfully");
		}else {
			System.out.println("Lead is not created Successfully");
		}
		return this;

	}

}
