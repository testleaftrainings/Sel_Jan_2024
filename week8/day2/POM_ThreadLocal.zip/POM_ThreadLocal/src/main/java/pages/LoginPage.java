package pages;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethods{
	

	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String uName) {
		
		try {
			getDriver().findElement(By.id("username123")).sendKeys(uName);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException("View Reports for more details");
		}
        return this;

	}

	@And("Enter the password as {string}")
	public LoginPage enterPassword(String pWord) {
		getDriver().findElement(By.id("password")).sendKeys(pWord);
		 return this;

	}

	@When("Click on Login button")
	public WelcomePage clickLoginButton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		 return new WelcomePage();
		 

	}

}
