package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class RunLogin extends ProjectSpecificMethods{
	
	@Test
	public void runLogin() {
		System.out.println(driver);
		/*
		 * LoginPage lp = new LoginPage(); lp.enterUsername(); lp.enterPassword();
		 * lp.clickLoginButton();
		 * 
		 * WelcomePage wp = new WelcomePage(); wp.verifyHomePage();
		 * //wp.clickCRMSFALink();
		 */
		
		LoginPage lp = new LoginPage();
		lp.enterUsername()
		.enterPassword()
		.clickLoginButton()
		.verifyHomePage()
		.clickCRMSFALink();
		
	}

}
