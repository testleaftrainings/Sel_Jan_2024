package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods{
	
	public WelcomePage verifyHomePage() {
		String text = driver.findElement(By.tagName("h2")).getText();
		if (text.contains("Welcome")) {
			System.out.println("HomePage is displayed");
		}
		else {
			System.out.println("HomePage is not displayed");
		}
		return this;

	}

	public MyHomePage clickCRMSFALink() {
		driver.findElement(By.partialLinkText("CRMSFA")).click();
		return new MyHomePage();

	}
	
}
